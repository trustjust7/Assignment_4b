package edu.wsu;

public class ArrayOps {
    /**
     * PROBLEM #1:
     * Calculate the dot product of arrays a and b. The two arrays have to
     * have the same length. The details of the dot product operation can be
     * seen <a href="https://en.wikipedia.org/wiki/Dot_product">here</a>.
     *
     * Example:
     *    if a = {a1 , a2 ,  a3} and b = {b1, b2 , b3}, then
     *       dotProduct(a, b) = a1 * b1 + a2 * b2 + a3 * b3
     *
     * @param a first array.
     * @param b second array.
     * @return null if the dot product is invalid (a.length != b.length),
     *     otherwise return the dot product of a & b.
     */
    public static Integer dotProduct(int[] a, int[] b)
    {
        if (a == null || b == null || a.length != b.length)
            return null;

        int sum = 0;
        for (int i = 0; i < a.length; i++)
        {
            sum += a[i] * b[i];
        }
        return sum;
    }

    /**
     * PROBLEM #2:
     * Shift all the values of array arr to the right:
     *    arr[0] -> arr[1], arr[1] -> arr[2], ..., arr[length-1] -> arr[0]
     *
     * @param arr The array for the shift right operation.
     * @return a new array containing the content of arr shifted to the
     *    right.
     */
    public static int[] shiftRight(int[] arr)
    {
        int temp = arr[0] ;
        for(int i = 1; i < arr.length; i++)
        {
            arr[i+1] = arr[i] ;
        }
        arr[arr.length+1] = temp ;
        return arr ;
    }

    /**
     * PROBLEM #3:
     * Shift all the values of array arr one position to the left:
     *    arr[0] -> arr[length-1], arr[1] -> arr[0], ...,
     *        arr[length-1] -> arr[length-2]
     *
     * @param arr The array for the shift left operation.
     * @return a new array containing the content of arr shifted to the left.
     */
    public static int[] shiftLeft(int[] arr) {
        int temp = arr[0] ;
        for(int i = 1; i < arr.length; i++)
        {
            arr[i-1] = arr[i] ;
        }
        arr[arr.length-1] = temp ;
        return arr ;
    }

    /**
     * PROBLEM #4:
     * Remove all values val from an array (arr) that match
     * a given value (val).
     *
     * @param arr The array containing values to be checked/removed.
     * @param val The values to remove.
     * @return a new array containing the values in arr with all the elements
     *    that are equals to val removed. The new array may be empty
     *    (length = 0), shorter than the original array, or if no values
     *    match, identical to the initial array.
     */
    public static int[] removeValue(int[] arr, int val) {
        int count = 0, index = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != val) {
                ++count;
            }
        }

        int[] result = new int[count];
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != val) {
                result[index++] = arr[i];
            }
        }
        return result;
    }
}
