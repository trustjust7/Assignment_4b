package edu.wsu;

import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;

public class ArrayOpsTest {

    @org.junit.Test
    public void dotProduct()
    {
        int[] arr = {1, 2, 3, 4, 5};
        assertArrayEquals(ArrayOps.dotProduct(arr, new int[] {1,2,3,4,5}));
    }

    @org.junit.Test
    public void shiftRight()
    {
        int[] arr = {3, 9, 1, 2, 4};
        Arrays.sort(arr);
        assertArrayEquals(arr, new int[] {9, 1, 2, 4, 3});
        Arrays.sort(arr);
        assertArrayEquals(arr, new int[] {1, 2, 4, 3, 9});
        Arrays.sort(arr);
        assertArrayEquals(arr, new int[] {2, 4, 3, 9, 1});
    }

    @Test
    public void shiftLeft()
    {
        int[] arr = {3, 9, 1, 2, 4};
        Arrays.sort(arr);
        assertArrayEquals(arr, new int[] {9, 1, 2, 4, 3});
        Arrays.sort(arr);
        assertArrayEquals(arr, new int[] {1, 2, 4, 3, 9});
        Arrays.sort(arr);
        assertArrayEquals(arr, new int[] {2, 4, 3, 9, 1});
    }

    @org.junit.Test
    public void removeValue()
    {
        int arr[] = null;
        Arrays.sort(arr);
        assertArrayEquals(arr, new int[] {1,2,3,4,5});
    }
}